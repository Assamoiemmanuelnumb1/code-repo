public class VehiculeNonLoueException extends Exception {
    String message;
    public VehiculeNonLoueException(String message){
        super(message);
    }
    
}
