public class VehiculeIndisponibleException extends Exception {
    String infos;
    public VehiculeIndisponibleException(String infos){
        super(infos);
        

    }

    
}
