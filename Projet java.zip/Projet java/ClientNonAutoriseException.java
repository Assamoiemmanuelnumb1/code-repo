public class ClientNonAutoriseException extends Exception{

    public ClientNonAutoriseException(String regle){
        super(regle);
    }
}