public class Camion extends Vehicule implements Louable{
    double capacitechargement;
    int nbreessieux;

    //Constructeur camion
    

    public Camion(String immatriculation, String marque, int anneeMiseenService, double kilometrage, String statut,double capacitechargement,int nbreessieux,String modele) {
        super(immatriculation, marque, anneeMiseenService, kilometrage, statut,modele);
        this.capacitechargement=capacitechargement;
        this.nbreessieux=nbreessieux;
    
        
        
    }

    
    double calculerPrixLocation() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calculerPrixLocation'");
    }

    @Override
    public void louerVehicule()throws VehiculeIndisponibleException,ClientNonAutoriseException{
        if (getstatut().equals("loué")){
            throw new VehiculeIndisponibleException("ce camion est déja loué"); 
        
        }
        else if(getstatut().equals("disponible")){    
            if(clien.ValidernumeroPermisdeconduire()){

                System.out.println("le camion est louable");
            }
                

            }
            else {
                throw new ClientNonAutoriseException("ce camion n'est pas louable");
            }        
            

    }
            
    


    @Override
    public void retournerVehicule() throws VehiculeNonLoueException{
      
        if (getstatut().equals("loué")){
            statut="disponible";
            System.out.println("Ce vehicule est : "+ statut);  
            
        }
        else{
    
    
            throw new VehiculeNonLoueException("Ce vehicule ne peut pas etre retourner");

        }  
    }
        
        
        
                
}  
        
    




