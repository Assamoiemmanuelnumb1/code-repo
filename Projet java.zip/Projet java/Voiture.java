public class Voiture extends Vehicule implements Louable {
    int nbreplaces;
    String typecarburant;

    public Voiture(String immatriculation, String marque, int anneeMiseenService, double kilometrage, String statut,String typecarburant,int nbreplaces,String modele) {
        super(immatriculation, marque, anneeMiseenService, kilometrage, statut,modele);
        this.nbreplaces=nbreplaces;
        this.typecarburant=typecarburant;
        
    }
    public int getnbreplaces(){
        return nbreplaces;
    }
    void setnbreplaces(){
        this.nbreplaces=nbreplaces;

    }
    public String gettypecarburant(){
        return typecarburant;
    }
    void settypecarburant(){
        this.typecarburant=typecarburant;
        
    }


    /*@Override
    double calculerPrixLocation() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calculerPrixLocation'");
    }
    private boolean estloue;
    public void louer(Vehicule voiture1) {
        this.estloue=true;
        statut="loue";
        System.out.println("le modele "+ voiture1.getmodele() +" est " + statut);
          
    }

    
    public void retourner(Vehicule voiture1) {
        this.estloue=false;
            statut="disponible";
        System.out.println(voiture1.getmodele()+ " est " + statut);
    }*/
    @Override

    public void louerVehicule()throws VehiculeIndisponibleException{
        if (getstatut().equals("loué")){
            throw new VehiculeIndisponibleException("ce vehicule est déja loué"); 
        
        }
            
        
        


           
        
    }
    @Override
    public void retournerVehicule() throws VehiculeNonLoueException{
      
        if (getstatut().equals("loué")){
            statut="disponible";
            System.out.println("Ce vehicule est : "+ statut);
            
            
        }
        else{
    
            throw new VehiculeNonLoueException("Ce vehicule ne peut pas etre retourner");

        }                     
       
        
    }
    @Override
    double calculerPrixLocation() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'calculerPrixLocation'");
    }
    

}