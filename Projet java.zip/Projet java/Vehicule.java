abstract class Vehicule  {
     String immatriculation;
     String marque;
     int anneeMiseenService;
     double kilometrage;
     String statut;
     String modele;
     //constructeur Vehicule
     public Vehicule(String immatriculation,String marque,int anneeMiseenService,double kilometrage,String statut,String modele){
        this.immatriculation=immatriculation;
        this.marque= marque;
        this.anneeMiseenService=anneeMiseenService;
        this.kilometrage=kilometrage;
        this.statut= statut;
        this.modele=modele;

     }
    // Getters and setters
     public String getimmatriculation(){
          return immatriculation;
     }
     public void setimmatriculation(){
      this.immatriculation=immatriculation;
     }
     public String getmarque(){
         return marque;

     }
   
 public void setmarque(){
  this.marque=marque;
 }
 
 public int getanneeMiseenService(){
   return anneeMiseenService;
}
public void setanneeMiseenService(){
this.anneeMiseenService=anneeMiseenService;
}

public double getkilometrage(){
   return kilometrage;
}
public void setkilometrage(){
this.kilometrage=kilometrage;
}

public String getstatut(){
   return statut;
}
public void setstatut(){
this.statut=statut;
}
public String getmodele(){
   return modele;


}
public void setmodele(){
   this.modele=modele;
}



     // methode calcul du prix de location


   abstract double calculerPrixLocation();
   
         }



    

