public class ParcAutomoblie{
    public static void main(String[] args) {

        
    }
    
}
