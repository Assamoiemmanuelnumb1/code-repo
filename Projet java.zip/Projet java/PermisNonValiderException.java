public class PermisNonValiderException extends Exception {
    String autreRegle;
    public PermisNonValiderException(String autreRegle){
        super(autreRegle);
    }
    
}
