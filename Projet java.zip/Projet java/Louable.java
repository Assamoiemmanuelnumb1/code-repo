public interface Louable {
    void louerVehicule() throws VehiculeIndisponibleException,ClientNonAutoriseException;
    void retournerVehicule()throws VehiculeNonLoueException;

    
} 