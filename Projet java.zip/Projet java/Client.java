import java.util.ArrayList;
import java.util.List;

public class Client{
     String nom;
    String prenom;
    String numeroPermisdeconduire;
    String numeroTelephone;
     List<Vehicule>locationsEncours ;
// Constructeur client
    public Client(String nom,String prenom,String numeroPermisdeconduire,String numeroTelephone ){
       this.nom=nom;
       this.prenom=prenom;
       this.numeroTelephone=numeroTelephone;
       this.numeroPermisdeconduire=numeroPermisdeconduire;
       locationsEncours=new ArrayList<>();

    }
    //Getters et setters

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNumeroPermisdeconduire() {
        return numeroPermisdeconduire;
    }

    public void setNumeroPermisdeconduire(String numeroPermisdeconduire) {
        this.numeroPermisdeconduire = numeroPermisdeconduire;
    }

    public String getNumeroTelephone() {
        return numeroTelephone;
    }

    public void setNumeroTelephone(String numeroTelephone) {

        this.numeroTelephone=numeroTelephone;
    }
    // methode pour ajouter un vehicule dans la liste locationEncours
    void ajouterLocation(Vehicule vehicule){

        locationsEncours.add(vehicule);
    }
    //methode pour valider le numero de permi de conduire
           public boolean ValidernumeroPermisdeconduire(Client client){
        String caracteres="ABCDE0123456789";
        int longueur=10;
            if(client.getNumeroPermisdeconduire().equals("0000000000"));
                return false;

            }
            
            for (int i = 0; i < numeroPermisdeconduire.length(); i++) 
             if(( client.getNumeroPermisdeconduire().length()==longueur)&&(caracteres.indexOf(numeroPermisdeconduire.charAt(i)) ==-1)) {
              return false;
            
             }
             
             
                
            return true;
            

        }

        private Object getnumeroPermisdeconduire() {
            // TODO Auto-generated method stub
            throw new UnsupportedOperationException("Unimplemented method 'getnumeroPermisdeconduire'");
        }
}


